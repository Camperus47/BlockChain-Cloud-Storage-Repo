const hre = require("hardhat");

async function main() {
  const ImageStorage = await hre.ethers.getContractFactory("ImageStorage");
  const imageStorage = await ImageStorage.deploy();

  await imageStorage.waitForDeployment();

  console.log("ImageStorage deployed to:", await imageStorage.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});