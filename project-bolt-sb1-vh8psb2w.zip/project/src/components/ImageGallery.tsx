import React, { useState, useEffect } from 'react';
import { Images, Eye, Share2, Lock, Unlock, Calendar, User, ExternalLink } from 'lucide-react';
import { ImageData } from '../types';

interface ImageGalleryProps {
  walletAddress: string;
  refresh: number;
  uploadedImages: (ImageData & { ipfsHash: string; previewUrl: string })[];
}

const ImageGallery: React.FC<ImageGalleryProps> = ({ walletAddress, refresh, uploadedImages }) => {
  const [images, setImages] = useState<(ImageData & { ipfsHash: string })[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<(ImageData & { ipfsHash: string }) | null>(null);
  const [userAddress, setUserAddress] = useState('');
  const [accessAddress, setAccessAddress] = useState('');

  const fetchImages = async (address: string = walletAddress) => {
    setLoading(true);
    try {
      // Simulate loading for now
      await new Promise(resolve => setTimeout(resolve, 1000));
      // Show uploaded images for the current user
      if (address.toLowerCase() === walletAddress.toLowerCase()) {
        setImages(uploadedImages);
      } else {
        setImages([]);
      }
    } catch (error) {
      console.error('Error fetching images:', error);
      setImages([]);
    } finally {
      setLoading(false);
    }
  };

  const handleGrantAccess = async () => {
    if (!selectedImage || !accessAddress.trim()) return;

    try {
      alert('Access granted successfully!');
      setAccessAddress('');
    } catch (error) {
      console.error('Error granting access:', error);
      alert('Failed to grant access');
    }
  };

  const handleRevokeAccess = async () => {
    if (!selectedImage || !accessAddress.trim()) return;

    try {
      alert('Access revoked successfully!');
      setAccessAddress('');
    } catch (error) {
      console.error('Error revoking access:', error);
      alert('Failed to revoke access');
    }
  };

  const formatDate = (timestamp: bigint) => {
    return new Date(Number(timestamp) * 1000).toLocaleDateString();
  };

  useEffect(() => {
    if (walletAddress) {
      fetchImages();
    }
  }, [walletAddress, refresh, uploadedImages]);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-purple-400 to-pink-500 p-2 rounded-xl">
            <Images className="h-6 w-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Image Gallery</h2>
        </div>

        {/* User Address Input */}
        <div className="flex space-x-4">
          <input
            type="text"
            placeholder="Enter user address to view their images"
            value={userAddress}
            onChange={(e) => setUserAddress(e.target.value)}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
          <button
            onClick={() => fetchImages(userAddress || walletAddress)}
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white px-6 py-3 rounded-xl font-medium transition-all duration-200 transform hover:scale-105"
          >
            Get Images
          </button>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        </div>
      )}

      {/* Images Grid */}
      {!loading && images.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {images.map((image, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden hover:scale-105 transition-all duration-200 cursor-pointer"
              onClick={() => setSelectedImage(image)}
            >
              <div className="aspect-square bg-gray-100 relative group">
                <img
                  src={`https://gateway.pinata.cloud/ipfs/${image.ipfsHash}`}
                  alt={image.description}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                  <Eye className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                </div>
              </div>
              <div className="p-4">
                <p className="font-medium text-gray-800 mb-2 line-clamp-2">{image.description}</p>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>{formatDate(image.timestamp)}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600 mt-1">
                  <User className="h-4 w-4" />
                  <span>{image.owner.slice(0, 8)}...{image.owner.slice(-6)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && images.length === 0 && (
        <div className="text-center py-12">
          <Images className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-600 mb-2">No images found</h3>
          <p className="text-gray-500">Upload some images or check access permissions</p>
        </div>
      )}

      {/* Image Modal */}
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex">
              {/* Image */}
              <div className="flex-1">
                <img
                  src={(selectedImage as any).previewUrl || `https://gateway.pinata.cloud/ipfs/${selectedImage.ipfsHash}`}
                  alt={selectedImage.description}
                  className="w-full h-96 object-contain bg-gray-100"
                />
              </div>
              
              {/* Details */}
              <div className="w-80 p-6 border-l border-gray-200">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-xl font-bold text-gray-800">Image Details</h3>
                  <button
                    onClick={() => setSelectedImage(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Description</label>
                    <p className="text-gray-800">{selectedImage.description}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Owner</label>
                    <p className="text-gray-800 text-sm font-mono">{selectedImage.owner}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Upload Date</label>
                    <p className="text-gray-800">{formatDate(selectedImage.timestamp)}</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">IPFS Hash</label>
                    <div className="flex items-center space-x-2">
                      <p className="text-gray-800 text-sm font-mono truncate">{selectedImage.ipfsHash}</p>
                      <a
                        href={`https://gateway.pinata.cloud/ipfs/${selectedImage.ipfsHash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                  </div>

                  {/* Access Control (only for owner) */}
                  {selectedImage.owner.toLowerCase() === walletAddress.toLowerCase() && (
                    <div className="space-y-3 pt-4 border-t border-gray-200">
                      <h4 className="font-medium text-gray-800">Access Control</h4>
                      
                      <input
                        type="text"
                        placeholder="User address"
                        value={accessAddress}
                        onChange={(e) => setAccessAddress(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                      />
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={handleGrantAccess}
                          className="flex-1 flex items-center justify-center space-x-2 bg-green-500 hover:bg-green-600 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                        >
                          <Unlock className="h-4 w-4" />
                          <span>Grant</span>
                        </button>
                        <button
                          onClick={handleRevokeAccess}
                          className="flex-1 flex items-center justify-center space-x-2 bg-red-500 hover:bg-red-600 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                        >
                          <Lock className="h-4 w-4" />
                          <span>Revoke</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ImageGallery;