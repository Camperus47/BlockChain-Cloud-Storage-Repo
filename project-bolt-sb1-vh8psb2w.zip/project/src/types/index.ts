export interface ImageData {
  ipfsHash: string;
  owner: string;
  timestamp: bigint;
  description: string;
  exists: boolean;
}

export interface WalletState {
  address: string | null;
  isConnected: boolean;
  isConnecting: boolean;
}

export interface UploadState {
  isUploading: boolean;
  progress: number;
  error: string | null;
}