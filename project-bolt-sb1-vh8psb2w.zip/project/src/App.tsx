import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import FileUpload from './components/FileUpload';
import ImageGallery from './components/ImageGallery';
import { WalletState, ImageData } from './types';

// Simple wallet connection function
const connectWallet = async (): Promise<string> => {
  if (typeof window.ethereum !== 'undefined') {
    try {
      await window.ethereum.request({ method: 'eth_requestAccounts' });
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      return accounts[0];
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    }
  } else {
    throw new Error('MetaMask is not installed');
  }
};

function App() {
  const [walletState, setWalletState] = useState<WalletState>({
    address: null,
    isConnected: false,
    isConnecting: false,
  });
  const [refreshGallery, setRefreshGallery] = useState(0);
  const [uploadedImages, setUploadedImages] = useState<(ImageData & { ipfsHash: string; previewUrl: string })[]>([]);

  const handleConnectWallet = async () => {
    setWalletState(prev => ({ ...prev, isConnecting: true }));
    
    try {
      const address = await connectWallet();
      setWalletState({
        address,
        isConnected: true,
        isConnecting: false,
      });
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      setWalletState(prev => ({ ...prev, isConnecting: false }));
      alert('Failed to connect wallet. Please make sure MetaMask is installed and unlocked.');
    }
  };

  const handleUploadSuccess = (imageData: ImageData & { ipfsHash: string; previewUrl: string }) => {
    setUploadedImages(prev => [imageData, ...prev]);
    setRefreshGallery(prev => prev + 1);
  };

  // Check if wallet is already connected
  useEffect(() => {
    const checkConnection = async () => {
      if (typeof window.ethereum !== 'undefined') {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            setWalletState({
              address: accounts[0],
              isConnected: true,
              isConnecting: false,
            });
          }
        } catch (error) {
          console.error('Failed to check wallet connection:', error);
        }
      }
    };

    checkConnection();

    // Listen for account changes
    if (typeof window.ethereum !== 'undefined') {
      window.ethereum.on('accountsChanged', (accounts: string[]) => {
        if (accounts.length > 0) {
          setWalletState({
            address: accounts[0],
            isConnected: true,
            isConnecting: false,
          });
        } else {
          setWalletState({
            address: null,
            isConnected: false,
            isConnecting: false,
          });
        }
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header
        walletAddress={walletState.address}
        isConnecting={walletState.isConnecting}
        onConnect={handleConnectWallet}
      />

      <main className="container mx-auto px-6 py-8">
        {!walletState.isConnected ? (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
            <div className="bg-white/20 backdrop-blur-md rounded-3xl border border-white/30 p-12 max-w-lg">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-4 rounded-full inline-block mb-6">
                <svg className="h-16 w-16 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                Welcome to DecentralDrive
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Connect your MetaMask wallet to start uploading and sharing images on the blockchain
              </p>
              <button
                onClick={handleConnectWallet}
                disabled={walletState.isConnecting}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-medium text-lg transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {walletState.isConnecting ? 'Connecting...' : 'Connect Wallet to Get Started'}
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <FileUpload onUploadSuccess={handleUploadSuccess} />
            </div>
            <div>
              <ImageGallery
                walletAddress={walletState.address!}
                refresh={refreshGallery}
                uploadedImages={uploadedImages}
              />
            </div>
          </div>
        )}
      </main>

      {/* Setup Instructions */}
      {!import.meta.env.VITE_PINATA_API_KEY && (
        <div className="fixed bottom-4 right-4 bg-yellow-50 border border-yellow-200 rounded-xl p-4 max-w-sm shadow-lg">
          <h3 className="font-medium text-yellow-800 mb-2">Setup Required</h3>
          <p className="text-sm text-yellow-700 mb-3">
            Please configure your Pinata API keys in the .env file to enable image uploads.
          </p>
          <ol className="text-xs text-yellow-600 list-decimal list-inside space-y-1">
            <li>Copy .env.example to .env</li>
            <li>Add your Pinata API keys</li>
            <li>Deploy the smart contract</li>
            <li>Update the contract address</li>
          </ol>
        </div>
      )}
    </div>
  );
}

export default App;